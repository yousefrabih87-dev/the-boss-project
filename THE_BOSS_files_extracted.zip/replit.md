# THE BOSS — نظام إشارات تداول الذهب

بوت تيليجرام ولوحة تحكم ويب لإشارات تداول الذهب باستخدام استراتيجية SMC + SK.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: In-memory (no database — trades reset on restart)
- Validation: Zod (`zod/v4`)
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Telegram: node-telegram-bot-api

## Where things live

- `lib/api-spec/openapi.yaml` — API contract source of truth
- `lib/api-client-react/src/generated/` — generated React Query hooks
- `lib/api-zod/src/generated/` — generated Zod schemas
- `artifacts/api-server/src/lib/goldEngine.ts` — Binance price fetching + signal generation
- `artifacts/api-server/src/lib/tradeStore.ts` — in-memory trade store
- `artifacts/api-server/src/lib/telegramBot.ts` — Telegram bot logic
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/dashboard/src/` — React frontend (Arabic RTL dashboard)

## Architecture decisions

- In-memory trade store — no DB provisioned; trades reset on server restart. Can be upgraded to PostgreSQL later.
- Telegram bot starts automatically when `TELEGRAM_TOKEN` is set in secrets.
- Gold price fetched live from Binance (`XAUT/USDT`); falls back to simulated price if Binance is unreachable.
- Signal generation uses SMC + SK strategy simulation (entry zone, target, stop-loss with 0.5% volatility band).
- Dashboard is Arabic-only RTL with dark metallic gold theme.

## Product

- **Telegram Bot**: Commands `/start`, `/price`, `/signal`, `/status`, `/stats`
- **Web Dashboard** (at `/`): Live gold price, bot status, trade stats, open/closed trades
- **Trade Management**: Generate signals, open trades, close with PnL
- **Auto-refresh**: Gold price every 10s, bot status every 5s, stats every 15s

## Telegram Bot Commands

- `/start` — Welcome message + command list
- `/price` — Current XAUT/USDT price from Binance
- `/signal` — Generate SMC + SK signal + auto-open trade
- `/status` — Bot status + list of open trades
- `/stats` — Win rate, PnL, trade counts

## User preferences

- Arabic RTL UI
- Dark metallic theme with gold (#D4AF37) accents
- No emojis in UI

## Gotchas

- `TELEGRAM_TOKEN` must be set in Replit Secrets for the bot to start
- Trade data is in-memory only — resets when API server restarts
- The `@workspace/db` dependency was removed — this server does NOT use PostgreSQL
- Binance XAUT/USDT API may be rate-limited; server falls back to simulated price
