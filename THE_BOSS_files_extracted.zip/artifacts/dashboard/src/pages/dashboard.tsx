import { useState } from "react";
import {
  useGetGoldPrice, useGetBotStatus, useGetTradeStats, useGetTrades,
  getGetGoldPriceQueryKey, getGetBotStatusQueryKey, getGetTradeStatsQueryKey, getGetTradesQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, TrendingUp, TrendingDown, DollarSign, Target, Crosshair, Clock } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const { data: goldPrice } = useGetGoldPrice({ query: { refetchInterval: 10000, queryKey: getGetGoldPriceQueryKey() } });
  const { data: botStatus } = useGetBotStatus({ query: { refetchInterval: 5000, queryKey: getGetBotStatusQueryKey() } });
  const { data: stats } = useGetTradeStats({ query: { refetchInterval: 15000, queryKey: getGetTradeStatsQueryKey() } });
  const { data: trades } = useGetTrades({ query: { refetchInterval: 15000, queryKey: getGetTradesQueryKey() } });

  const openTrades = trades?.filter(t => t.status === "OPEN") || [];
  const recentClosedTrades = trades?.filter(t => t.status !== "OPEN" && t.status !== "CANCELLED").slice(0, 5) || [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">نظرة عامة</h2>
          <p className="text-muted-foreground">ملخص أداء التداول وحالة النظام</p>
        </div>
        
        <div className="flex gap-4">
          <Card className="bg-card/50 border-primary/20 gold-glow min-w-[200px]">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">سعر الذهب المباشر</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-2xl font-bold text-foreground">
                    {goldPrice?.price ? `$${goldPrice.price.toFixed(2)}` : "---"}
                  </span>
                  <Activity className="h-4 w-4 text-primary animate-pulse" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card/50 min-w-[180px]">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">حالة البوت</p>
                <div className="flex items-center gap-2 mt-1">
                  <div className={cn("h-3 w-3 rounded-full", botStatus?.botActive ? "bg-green-500" : "bg-red-500")} />
                  <span className="text-lg font-bold">
                    {botStatus?.botActive ? "نشط" : "متوقف"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الصفقات</CardTitle>
            <Target className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalTrades || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats?.todayTrades || 0} صفقة اليوم
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">نسبة النجاح</CardTitle>
            <Crosshair className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.winRate ? `${stats.winRate.toFixed(1)}%` : "0%"}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats?.wins || 0} ربح / {stats?.losses || 0} خسارة
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">أرباح اليوم (PnL)</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className={cn("text-2xl font-bold", (stats?.todayPnl || 0) >= 0 ? "text-green-500" : "text-red-500")}>
              ${stats?.todayPnl?.toFixed(2) || "0.00"}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الأرباح</CardTitle>
            <Activity className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className={cn("text-2xl font-bold", (stats?.totalPnl || 0) >= 0 ? "text-green-500" : "text-red-500")}>
              ${stats?.totalPnl?.toFixed(2) || "0.00"}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="col-span-1 border-border/50">
          <CardHeader>
            <CardTitle>الصفقات المفتوحة ({openTrades.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {openTrades.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                لا توجد صفقات مفتوحة حالياً
              </div>
            ) : (
              <div className="space-y-4">
                {openTrades.map(trade => (
                  <div key={trade.id} className="flex items-center justify-between p-4 rounded-lg border border-border bg-card hover:bg-accent/5 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={cn("p-2 rounded-full", trade.direction === 'BUY' ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500")}>
                        {trade.direction === 'BUY' ? <TrendingUp size={20} /> : <TrendingDown size={20} />}
                      </div>
                      <div>
                        <div className="font-bold">{trade.direction === 'BUY' ? 'شراء' : 'بيع'} XAUT</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-1">
                          <Clock size={12} /> {format(new Date(trade.openedAt), 'HH:mm')}
                        </div>
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="text-sm text-muted-foreground">الدخول</div>
                      <div className="font-mono font-medium">${trade.entryPrice}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1 border-border/50">
          <CardHeader>
            <CardTitle>أحدث الصفقات المغلقة</CardTitle>
          </CardHeader>
          <CardContent>
            {recentClosedTrades.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                لا توجد صفقات مغلقة
              </div>
            ) : (
              <div className="space-y-4">
                {recentClosedTrades.map(trade => (
                  <div key={trade.id} className="flex items-center justify-between p-4 rounded-lg border border-border bg-card">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className={cn(
                        trade.status === 'CLOSED_WIN' ? "border-green-500 text-green-500" : "border-red-500 text-red-500"
                      )}>
                        {trade.status === 'CLOSED_WIN' ? 'ربح' : 'خسارة'}
                      </Badge>
                      <div>
                        <div className="font-bold text-sm">{trade.direction === 'BUY' ? 'شراء' : 'بيع'}</div>
                        <div className="text-xs text-muted-foreground">{trade.strategy}</div>
                      </div>
                    </div>
                    <div className="text-left">
                      <div className={cn("font-mono font-bold", (trade.pnl || 0) >= 0 ? "text-green-500" : "text-red-500")}>
                        {(trade.pnl || 0) >= 0 ? "+" : ""}${trade.pnl?.toFixed(2)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
