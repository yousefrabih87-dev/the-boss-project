import { useState } from "react";
import { useGetTrades, useUpdateTrade, getGetTradesQueryKey, getGetTradeStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function Trades() {
  const { data: trades, isLoading } = useGetTrades();
  const queryClient = useQueryClient();
  const updateTrade = useUpdateTrade();
  
  const [closeTradeDialog, setCloseTradeDialog] = useState<{ isOpen: boolean; tradeId: string | null; pnl: string; status: 'CLOSED_WIN' | 'CLOSED_LOSS' }>({
    isOpen: false,
    tradeId: null,
    pnl: "",
    status: 'CLOSED_WIN'
  });

  const handleCloseTrade = () => {
    if (!closeTradeDialog.tradeId || !closeTradeDialog.pnl) return;
    
    updateTrade.mutate({
      id: closeTradeDialog.tradeId,
      data: {
        status: closeTradeDialog.status,
        pnl: parseFloat(closeTradeDialog.pnl),
        closedAt: new Date().toISOString()
      }
    }, {
      onSuccess: () => {
        setCloseTradeDialog({ isOpen: false, tradeId: null, pnl: "", status: 'CLOSED_WIN' });
        queryClient.invalidateQueries({ queryKey: getGetTradesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetTradeStatsQueryKey() });
      }
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'OPEN': return <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20 hover:bg-blue-500/20">مفتوحة</Badge>;
      case 'CLOSED_WIN': return <Badge className="bg-green-500/10 text-green-500 border-green-500/20 hover:bg-green-500/20">ربح</Badge>;
      case 'CLOSED_LOSS': return <Badge className="bg-red-500/10 text-red-500 border-red-500/20 hover:bg-red-500/20">خسارة</Badge>;
      case 'CANCELLED': return <Badge className="bg-gray-500/10 text-gray-500 border-gray-500/20 hover:bg-gray-500/20">ملغاة</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">سجل الصفقات</h2>
        <p className="text-muted-foreground">عرض وتحديث جميع الصفقات</p>
      </div>

      <Card className="border-border/50">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-right">التاريخ</TableHead>
                <TableHead className="text-right">الاتجاه</TableHead>
                <TableHead className="text-right text-xs">سعر الدخول</TableHead>
                <TableHead className="text-right text-xs">الهدف</TableHead>
                <TableHead className="text-right text-xs">وقف الخسارة</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">الربح/الخسارة</TableHead>
                <TableHead className="text-right">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8">جاري التحميل...</TableCell>
                </TableRow>
              ) : trades?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8">لا توجد صفقات</TableCell>
                </TableRow>
              ) : (
                trades?.map((trade) => (
                  <TableRow key={trade.id} className="border-border">
                    <TableCell className="whitespace-nowrap">{format(new Date(trade.openedAt), 'yyyy-MM-dd HH:mm')}</TableCell>
                    <TableCell>
                      <span className={cn("font-bold", trade.direction === 'BUY' ? "text-green-500" : "text-red-500")}>
                        {trade.direction === 'BUY' ? 'شراء' : 'بيع'}
                      </span>
                    </TableCell>
                    <TableCell className="font-mono">${trade.entryPrice}</TableCell>
                    <TableCell className="font-mono text-green-500">${trade.target}</TableCell>
                    <TableCell className="font-mono text-red-500">${trade.stopLoss}</TableCell>
                    <TableCell>{getStatusBadge(trade.status)}</TableCell>
                    <TableCell>
                      {trade.status !== 'OPEN' && trade.status !== 'CANCELLED' && trade.pnl !== undefined && (
                        <span className={cn("font-mono font-bold", trade.pnl >= 0 ? "text-green-500" : "text-red-500")}>
                          {trade.pnl >= 0 ? "+" : ""}${trade.pnl}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>
                      {trade.status === 'OPEN' && (
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-green-500 border-green-500/50 hover:bg-green-500/10"
                            onClick={() => setCloseTradeDialog({ isOpen: true, tradeId: trade.id, pnl: "", status: 'CLOSED_WIN' })}
                          >
                            ربح
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-red-500 border-red-500/50 hover:bg-red-500/10"
                            onClick={() => setCloseTradeDialog({ isOpen: true, tradeId: trade.id, pnl: "", status: 'CLOSED_LOSS' })}
                          >
                            خسارة
                          </Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={closeTradeDialog.isOpen} onOpenChange={(open) => !open && setCloseTradeDialog(prev => ({...prev, isOpen: false}))}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إغلاق الصفقة</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>قيمة الربح/الخسارة (PnL)</Label>
              <Input 
                type="number" 
                placeholder="أدخل القيمة (مثال: 50 أو -30)" 
                value={closeTradeDialog.pnl}
                onChange={(e) => setCloseTradeDialog(prev => ({...prev, pnl: e.target.value}))}
                className="font-mono text-left"
                dir="ltr"
              />
            </div>
          </div>
          <DialogFooter className="flex-row-reverse sm:flex-row-reverse gap-2">
            <Button variant="outline" onClick={() => setCloseTradeDialog(prev => ({...prev, isOpen: false}))}>إلغاء</Button>
            <Button 
              onClick={handleCloseTrade} 
              disabled={!closeTradeDialog.pnl || updateTrade.isPending}
            >
              {updateTrade.isPending ? 'جاري الحفظ...' : 'تأكيد الإغلاق'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
