import { useState } from "react";
import { useGenerateSignal, useCreateTrade, getGetTradesQueryKey, getGetTradeStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, TrendingUp, TrendingDown, Crosshair, Target, ShieldAlert, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function Signal() {
  const generateSignal = useGenerateSignal();
  const createTrade = useCreateTrade();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleGenerateSignal = () => {
    generateSignal.mutate(undefined, {
      onError: () => {
        toast({
          title: "خطأ",
          description: "فشل في توليد الإشارة",
          variant: "destructive"
        });
      }
    });
  };

  const handleExecuteTrade = () => {
    if (!generateSignal.data) return;
    
    const signalData = generateSignal.data;
    
    createTrade.mutate({
      data: {
        direction: signalData.direction as 'BUY' | 'SELL',
        entryPrice: signalData.price,
        target: signalData.target,
        stopLoss: signalData.stopLoss,
        strategy: signalData.strategy
      }
    }, {
      onSuccess: () => {
        toast({
          title: "تم التنفيذ",
          description: "تم فتح الصفقة بنجاح"
        });
        queryClient.invalidateQueries({ queryKey: getGetTradesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetTradeStatsQueryKey() });
      },
      onError: () => {
        toast({
          title: "خطأ",
          description: "فشل في فتح الصفقة",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">توليد إشارة</h2>
        <p className="text-muted-foreground">توليد إشارة تداول جديدة باستخدام استراتيجية SMC + SK</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-border/50 col-span-1 flex flex-col justify-between">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="text-primary h-5 w-5" />
              محرك الاستراتيجية
            </CardTitle>
            <CardDescription>
              سيقوم النظام بتحليل حركة السعر الحالية (Price Action)، مناطق السيولة (Liquidity)، والكتل الإلزامية (Order Blocks) لتحديد أفضل فرصة دخول.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <Button 
              className="w-full text-lg h-14 font-bold bg-primary text-primary-foreground hover:bg-primary/90 gold-glow"
              onClick={handleGenerateSignal}
              disabled={generateSignal.isPending}
            >
              {generateSignal.isPending ? (
                <>
                  <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                  جاري تحليل السوق...
                </>
              ) : (
                "توليد إشارة الآن"
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className={cn("border-border/50 col-span-1 transition-all duration-500", generateSignal.data ? "opacity-100 translate-y-0" : "opacity-50 pointer-events-none")}>
          <CardHeader>
            <CardTitle>نتيجة التحليل</CardTitle>
          </CardHeader>
          <CardContent>
            {generateSignal.data ? (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="text-lg font-medium text-muted-foreground">الاتجاه المتوقع</div>
                  <Badge className={cn(
                    "text-xl px-4 py-1", 
                    generateSignal.data.direction === 'BUY' ? "bg-green-500/20 text-green-500 hover:bg-green-500/30" : "bg-red-500/20 text-red-500 hover:bg-red-500/30"
                  )}>
                    {generateSignal.data.direction === 'BUY' ? (
                      <span className="flex items-center gap-2"><TrendingUp /> شراء (BUY)</span>
                    ) : (
                      <span className="flex items-center gap-2"><TrendingDown /> بيع (SELL)</span>
                    )}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-secondary/50 p-4 rounded-lg border border-border">
                    <div className="text-sm text-muted-foreground flex items-center gap-2 mb-1">
                      <Crosshair size={14} /> سعر الدخول
                    </div>
                    <div className="font-mono text-xl font-bold">${generateSignal.data.price}</div>
                  </div>
                  
                  <div className="bg-secondary/50 p-4 rounded-lg border border-border">
                    <div className="text-sm text-muted-foreground flex items-center gap-2 mb-1">
                      الاستراتيجية
                    </div>
                    <div className="font-bold">{generateSignal.data.strategy}</div>
                  </div>

                  <div className="bg-green-500/5 p-4 rounded-lg border border-green-500/20">
                    <div className="text-sm text-green-500/70 flex items-center gap-2 mb-1">
                      <Target size={14} /> الهدف (TP)
                    </div>
                    <div className="font-mono text-xl font-bold text-green-500">${generateSignal.data.target}</div>
                  </div>

                  <div className="bg-red-500/5 p-4 rounded-lg border border-red-500/20">
                    <div className="text-sm text-red-500/70 flex items-center gap-2 mb-1">
                      <ShieldAlert size={14} /> وقف الخسارة (SL)
                    </div>
                    <div className="font-mono text-xl font-bold text-red-500">${generateSignal.data.stopLoss}</div>
                  </div>
                </div>

                <Button 
                  className="w-full mt-4" 
                  onClick={handleExecuteTrade}
                  disabled={createTrade.isPending}
                >
                  {createTrade.isPending ? "جاري التنفيذ..." : "تنفيذ الصفقة"}
                </Button>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                قم بتوليد إشارة لعرض النتائج
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
