import { Link, useLocation } from "wouter";
import { Activity, LayoutDashboard, History, PlusCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();

  const navigation = [
    { name: "لوحة القيادة", href: "/", icon: LayoutDashboard },
    { name: "سجل الصفقات", href: "/trades", icon: History },
    { name: "توليد إشارة", href: "/signal", icon: PlusCircle },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-card border-l border-border flex flex-col">
        <div className="p-6 flex items-center gap-3 border-b border-border">
          <Activity className="h-8 w-8 text-primary" />
          <h1 className="font-bold text-2xl tracking-wider text-primary">THE BOSS</h1>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <Link key={item.name} href={item.href}>
                <div
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-md transition-all cursor-pointer font-medium",
                    isActive
                      ? "bg-primary/10 text-primary border border-primary/20"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
