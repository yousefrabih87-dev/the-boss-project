import { Router, type IRouter } from "express";
import { fetchLivePrice, generateSignal } from "../lib/goldEngine";

const router: IRouter = Router();

router.get("/gold/price", async (req, res) => {
  try {
    const data = await fetchLivePrice();
    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get gold price");
    res.status(500).json({ error: "Failed to fetch price" });
  }
});

router.post("/gold/signal", async (req, res) => {
  try {
    const { price } = await fetchLivePrice();
    const signal = generateSignal(price);
    res.json(signal);
  } catch (err) {
    req.log.error({ err }, "Failed to generate signal");
    res.status(500).json({ error: "Failed to generate signal" });
  }
});

export default router;
