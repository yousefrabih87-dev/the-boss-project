import { Router, type IRouter } from "express";
import {
  getAllTrades,
  createTrade,
  updateTrade,
  getTradeStats,
} from "../lib/tradeStore";
import { getBotStatus } from "../lib/telegramBot";

const router: IRouter = Router();

router.get("/trades/stats", (_req, res) => {
  res.json(getTradeStats());
});

router.get("/bot/status", (_req, res) => {
  res.json(getBotStatus());
});

router.get("/trades", (_req, res) => {
  res.json(getAllTrades());
});

router.post("/trades", async (req, res) => {
  const { direction, entryPrice, target, stopLoss, strategy } = req.body as {
    direction: "BUY" | "SELL";
    entryPrice: number;
    target: number;
    stopLoss: number;
    strategy?: string;
  };

  if (!direction || !entryPrice || !target || !stopLoss) {
    res.status(400).json({ error: "Missing required fields" });
    return;
  }

  const trade = createTrade({ direction, entryPrice, target, stopLoss, strategy });
  res.status(201).json(trade);
});

router.patch("/trades/:id", (req, res) => {
  const { id } = req.params;
  const input = req.body as {
    status?: "CLOSED_WIN" | "CLOSED_LOSS" | "CANCELLED";
    closedAt?: string;
    pnl?: number;
  };

  const updated = updateTrade(id, {
    ...input,
    closedAt: input.status ? new Date().toISOString() : input.closedAt,
  });

  if (!updated) {
    res.status(404).json({ error: "Trade not found" });
    return;
  }

  res.json(updated);
});

export default router;
