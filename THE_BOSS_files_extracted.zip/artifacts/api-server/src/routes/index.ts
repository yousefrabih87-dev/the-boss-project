import { Router, type IRouter } from "express";
import healthRouter from "./health";
import goldRouter from "./gold";
import tradesRouter from "./trades";

const router: IRouter = Router();

router.use(healthRouter);
router.use(goldRouter);
router.use(tradesRouter);

export default router;
