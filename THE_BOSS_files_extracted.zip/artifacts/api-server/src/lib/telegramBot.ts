import TelegramBot from "node-telegram-bot-api";
import { logger } from "./logger";
import { fetchLivePrice, generateSignal } from "./goldEngine";
import { createTrade, getAllTrades, updateTrade, getTradeStats } from "./tradeStore";

function getWebUrl(): string {
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) {
    const primary = domains.split(",")[0]?.trim();
    if (primary) return `https://${primary}`;
  }
  return "غير متاح — قم بنشر المشروع أولاً";
}

function getAdminKeyboard(autoEnabled: boolean) {
  return {
    keyboard: [
      [{ text: "💰 معرفة السعر الحالي للذهب" }, { text: "📊 حالة المحرك" }],
      [{ text: "🎯 طلب صفقة حقيقية (SMC + SK)" }, { text: "📈 الإحصائيات" }],
      [
        { text: autoEnabled ? "🔴 إيقاف الإشارات التلقائية" : "🟢 تفعيل الإشارات التلقائية" },
        { text: "🔗 رابط الويب (للـ UptimeRobot)" },
      ],
    ],
    resize_keyboard: true,
  };
}

let bot: TelegramBot | null = null;
let botActive = false;
let lastSignalAt: string | null = null;

// Subscribed chats
const subscribedChats = new Set<number>();

// Auto-signal scheduler
let autoSignalEnabled = false;
let autoSignalInterval: ReturnType<typeof setInterval> | null = null;
const AUTO_SIGNAL_HOURS = 4;

// Price monitor — checks every 60s if open trade hit TP or SL
let priceMonitorInterval: ReturnType<typeof setInterval> | null = null;
const PRICE_MONITOR_INTERVAL_MS = 60_000;

// ── Helpers ────────────────────────────────────────────────────────────────

/** Returns the single open trade, or null if none */
function getOpenTrade() {
  return getAllTrades().find((t) => t.status === "OPEN") ?? null;
}

/** Broadcast a message to all subscribed chats */
async function broadcast(text: string) {
  if (!bot || subscribedChats.size === 0) return;
  for (const chatId of subscribedChats) {
    await bot.sendMessage(chatId, text, { parse_mode: "Markdown" }).catch(() => {});
  }
}

// ── Price Monitor ──────────────────────────────────────────────────────────

async function checkOpenTrade() {
  const trade = getOpenTrade();
  if (!trade) return;

  let currentPrice: number;
  try {
    const result = await fetchLivePrice();
    currentPrice = result.price;
  } catch {
    return; // price fetch failed, skip this tick
  }

  const hitTarget =
    trade.direction === "BUY"
      ? currentPrice >= trade.target
      : currentPrice <= trade.target;

  const hitStop =
    trade.direction === "BUY"
      ? currentPrice <= trade.stopLoss
      : currentPrice >= trade.stopLoss;

  if (hitTarget) {
    const pnl = parseFloat(
      (trade.direction === "BUY"
        ? trade.target - trade.entryPrice
        : trade.entryPrice - trade.target
      ).toFixed(2)
    );
    const pnlPoints = Math.round(pnl / 0.10);

    updateTrade(trade.id, {
      status: "CLOSED_WIN",
      closedAt: new Date().toISOString(),
      pnl,
    });

    const msg =
      `🎯✅ *جاب الهدف — الصفقة رابحة!*\n\n` +
      `📊 ${trade.direction === "BUY" ? "🟢 شراء" : "🔴 بيع"}\n` +
      `🚪 الدخول: $${trade.entryPrice}\n` +
      `🏁 الإغلاق: $${currentPrice.toFixed(2)}\n` +
      `💰 الربح: *+${pnlPoints} نقطة (+$${pnl})*\n\n` +
      `🔓 _النظام جاهز لاستقبال إشارة جديدة_`;
    await broadcast(msg);
    logger.info({ tradeId: trade.id, pnl }, "Trade closed — TARGET hit");
  } else if (hitStop) {
    const loss = parseFloat(
      (trade.direction === "BUY"
        ? trade.entryPrice - trade.stopLoss
        : trade.stopLoss - trade.entryPrice
      ).toFixed(2)
    );
    const lossPoints = Math.round(loss / 0.10);

    updateTrade(trade.id, {
      status: "CLOSED_LOSS",
      closedAt: new Date().toISOString(),
      pnl: -loss,
    });

    const msg =
      `🛑❌ *ضرب الستوب — الصفقة خاسرة*\n\n` +
      `📊 ${trade.direction === "BUY" ? "🟢 شراء" : "🔴 بيع"}\n` +
      `🚪 الدخول: $${trade.entryPrice}\n` +
      `🏁 الإغلاق: $${currentPrice.toFixed(2)}\n` +
      `💸 الخسارة: *-${lossPoints} نقطة (-$${loss})*\n\n` +
      `🔓 _النظام جاهز لاستقبال إشارة جديدة_`;
    await broadcast(msg);
    logger.info({ tradeId: trade.id, loss }, "Trade closed — STOP hit");
  }
}

function startPriceMonitor() {
  if (priceMonitorInterval) return;
  priceMonitorInterval = setInterval(() => {
    checkOpenTrade().catch((err) =>
      logger.error({ err }, "Price monitor error")
    );
  }, PRICE_MONITOR_INTERVAL_MS);
  logger.info("Price monitor started (60s interval)");
}

// ── Auto-signal scheduler ──────────────────────────────────────────────────

async function broadcastSignal() {
  if (!bot || subscribedChats.size === 0) return;

  // Block if a trade is already open
  const existing = getOpenTrade();
  if (existing) {
    logger.info("Auto-signal skipped — trade already open");
    return;
  }

  try {
    const { price } = await fetchLivePrice();
    const signal = generateSignal(price);
    lastSignalAt = new Date().toISOString();
    createTrade({
      direction: signal.direction,
      entryPrice: signal.entryZone,
      target: signal.target,
      stopLoss: signal.stopLoss,
      strategy: signal.strategy,
    });
    const text = `📡 *إشارة تلقائية — THE BOSS*\n\n${signal.signal}`;
    await broadcast(text);
    logger.info({ chats: subscribedChats.size }, "Auto signal broadcast sent");
  } catch (err) {
    logger.error({ err }, "Auto signal broadcast failed");
  }
}

function startAutoSignals() {
  if (autoSignalInterval) clearInterval(autoSignalInterval);
  autoSignalEnabled = true;
  autoSignalInterval = setInterval(broadcastSignal, AUTO_SIGNAL_HOURS * 60 * 60 * 1000);
  logger.info({ intervalHours: AUTO_SIGNAL_HOURS }, "Auto signal scheduler started");
}

function stopAutoSignals() {
  if (autoSignalInterval) {
    clearInterval(autoSignalInterval);
    autoSignalInterval = null;
  }
  autoSignalEnabled = false;
  logger.info("Auto signal scheduler stopped");
}

// ── Signal handler (shared logic) ─────────────────────────────────────────

async function handleSignalRequest(chatId: number) {
  if (!bot) return;

  // Guard: one trade at a time
  const existing = getOpenTrade();
  if (existing) {
    const pnlLive =
      existing.direction === "BUY"
        ? `الهدف: $${existing.target} | وقف: $${existing.stopLoss}`
        : `الهدف: $${existing.target} | وقف: $${existing.stopLoss}`;
    await bot.sendMessage(
      chatId,
      `⏳ *يوجد صفقة مفتوحة حالياً*\n\n` +
        `📊 ${existing.direction === "BUY" ? "🟢 شراء" : "🔴 بيع"} @ $${existing.entryPrice}\n` +
        `${pnlLive}\n\n` +
        `_لن تُرسل إشارة جديدة حتى تُغلق هذه الصفقة بهدف أو وقف خسارة._`,
      { parse_mode: "Markdown" }
    );
    return;
  }

  try {
    const { price } = await fetchLivePrice();
    const signal = generateSignal(price);
    lastSignalAt = new Date().toISOString();
    createTrade({
      direction: signal.direction,
      entryPrice: signal.entryZone,
      target: signal.target,
      stopLoss: signal.stopLoss,
      strategy: signal.strategy,
    });
    await bot.sendMessage(chatId, signal.signal, { parse_mode: "Markdown" });
  } catch {
    await bot.sendMessage(chatId, "❌ تعذر توليد الإشارة، حاول مرة أخرى.");
  }
}

// ── Exports ────────────────────────────────────────────────────────────────

export function getBotStatus() {
  const openTrades = getAllTrades().filter((t) => t.status === "OPEN").length;
  return {
    botActive,
    engineStatus: botActive ? "نشط ✅" : "متوقف ⚠️",
    activeTrades: openTrades,
    lastSignalAt,
    currentPrice: null as number | null,
  };
}

export function startBot() {
  const token = process.env["TELEGRAM_TOKEN"];
  if (!token) {
    logger.warn("TELEGRAM_TOKEN not set — bot will not start");
    return;
  }

  try {
    bot = new TelegramBot(token, { polling: true });
    botActive = true;
    logger.info("Telegram bot started");

    // Start price monitor immediately
    startPriceMonitor();

    // ── /start ──────────────────────────────────────────────
    bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      subscribedChats.add(chatId);
      await bot!.sendMessage(
        chatId,
        "🚀 *مرحباً بك في نظام THE BOSS*\n\nإشارات الذهب SMC + SK — صفقة واحدة في وقت واحد.\n\nاختر من القائمة:",
        { parse_mode: "Markdown", reply_markup: getAdminKeyboard(autoSignalEnabled) }
      );
    });

    // ── /price ──────────────────────────────────────────────
    bot.onText(/\/price/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        const { price, symbol, source } = await fetchLivePrice();
        await bot!.sendMessage(
          chatId,
          `🪙 *السعر الحالي*\n${symbol}: *$${price.toFixed(2)}*\n_المصدر: ${source}_`,
          { parse_mode: "Markdown" }
        );
      } catch {
        await bot!.sendMessage(chatId, "❌ تعذر جلب السعر، حاول مرة أخرى.");
      }
    });

    // ── /signal ─────────────────────────────────────────────
    bot.onText(/\/signal/, async (msg) => {
      subscribedChats.add(msg.chat.id);
      await handleSignalRequest(msg.chat.id);
    });

    // ── /status ─────────────────────────────────────────────
    bot.onText(/\/status/, async (msg) => {
      const chatId = msg.chat.id;
      const status = getBotStatus();
      const openTrade = getOpenTrade();
      let text =
        `📊 *حالة النظام*\nالبوت: ${status.engineStatus}\n` +
        `صفقات مفتوحة: ${status.activeTrades}\n` +
        `الإشارات التلقائية: ${autoSignalEnabled ? `✅ نشطة (كل ${AUTO_SIGNAL_HOURS} ساعات)` : "❌ متوقفة"}`;
      if (openTrade) {
        text +=
          `\n\n*الصفقة المفتوحة:*\n` +
          `• ${openTrade.direction === "BUY" ? "🟢 شراء" : "🔴 بيع"} @ $${openTrade.entryPrice}\n` +
          `  🎯 هدف: $${openTrade.target} | 🛑 وقف: $${openTrade.stopLoss}`;
      } else {
        text += `\n\n✅ لا توجد صفقة مفتوحة — جاهز للإشارة التالية`;
      }
      await bot!.sendMessage(chatId, text, { parse_mode: "Markdown" });
    });

    // ── /stats ──────────────────────────────────────────────
    bot.onText(/\/stats/, async (msg) => {
      const chatId = msg.chat.id;
      const stats = getTradeStats();
      const text =
        `📈 *إحصائيات THE BOSS*\n\n` +
        `📊 إجمالي الصفقات: ${stats.totalTrades}\n` +
        `📅 صفقات اليوم: ${stats.todayTrades}\n` +
        `✅ فوز: ${stats.wins} | ❌ خسارة: ${stats.losses}\n` +
        `🎯 نسبة الفوز: ${stats.winRate}%\n` +
        `💰 إجمالي الأرباح: $${stats.totalPnl}\n` +
        `📆 أرباح اليوم: $${stats.todayPnl}`;
      await bot!.sendMessage(chatId, text, { parse_mode: "Markdown" });
    });

    // ── /autostart & /autostop ──────────────────────────────
    bot.onText(/\/autostart/, async (msg) => {
      subscribedChats.add(msg.chat.id);
      startAutoSignals();
      await bot!.sendMessage(
        msg.chat.id,
        `✅ *تم تفعيل الإشارات التلقائية*\nإشارة كل *${AUTO_SIGNAL_HOURS} ساعات* — صفقة واحدة في وقت واحد فقط.`,
        { parse_mode: "Markdown", reply_markup: getAdminKeyboard(true) }
      );
    });

    bot.onText(/\/autostop/, async (msg) => {
      stopAutoSignals();
      await bot!.sendMessage(
        msg.chat.id,
        "🔴 *تم إيقاف الإشارات التلقائية.*",
        { parse_mode: "Markdown", reply_markup: getAdminKeyboard(false) }
      );
    });

    // ── Keyboard button handlers ────────────────────────────
    bot.on("message", async (msg) => {
      const chatId = msg.chat.id;
      const text = msg.text;
      subscribedChats.add(chatId);

      if (text === "💰 معرفة السعر الحالي للذهب") {
        try {
          const { price, symbol, source } = await fetchLivePrice();
          await bot!.sendMessage(
            chatId,
            `🪙 *السعر الحالي*\n${symbol}: *$${price.toFixed(2)}*\n_المصدر: ${source}_`,
            { parse_mode: "Markdown" }
          );
        } catch {
          await bot!.sendMessage(chatId, "❌ تعذر جلب السعر، حاول مرة أخرى.");
        }

      } else if (text === "📊 حالة المحرك") {
        const status = getBotStatus();
        const openTrade = getOpenTrade();
        let reply =
          `📊 *حالة النظام*\nالبوت: ${status.engineStatus}\n` +
          `صفقات مفتوحة: ${status.activeTrades}\n` +
          `الإشارات التلقائية: ${autoSignalEnabled ? `✅ نشطة (كل ${AUTO_SIGNAL_HOURS} ساعات)` : "❌ متوقفة"}`;
        if (openTrade) {
          reply +=
            `\n\n*الصفقة المفتوحة:*\n` +
            `• ${openTrade.direction === "BUY" ? "🟢 شراء" : "🔴 بيع"} @ $${openTrade.entryPrice}\n` +
            `  🎯 هدف: $${openTrade.target} | 🛑 وقف: $${openTrade.stopLoss}`;
        } else {
          reply += `\n\n✅ لا توجد صفقة مفتوحة — جاهز للإشارة التالية`;
        }
        await bot!.sendMessage(chatId, reply, { parse_mode: "Markdown" });

      } else if (text === "🎯 طلب صفقة حقيقية (SMC + SK)") {
        await handleSignalRequest(chatId);

      } else if (text === "📈 الإحصائيات") {
        const stats = getTradeStats();
        const reply =
          `📈 *إحصائيات THE BOSS*\n\n` +
          `📊 إجمالي الصفقات: ${stats.totalTrades}\n` +
          `📅 صفقات اليوم: ${stats.todayTrades}\n` +
          `✅ فوز: ${stats.wins} | ❌ خسارة: ${stats.losses}\n` +
          `🎯 نسبة الفوز: ${stats.winRate}%\n` +
          `💰 إجمالي الأرباح: $${stats.totalPnl}\n` +
          `📆 أرباح اليوم: $${stats.todayPnl}`;
        await bot!.sendMessage(chatId, reply, { parse_mode: "Markdown" });

      } else if (text === "🟢 تفعيل الإشارات التلقائية") {
        startAutoSignals();
        await bot!.sendMessage(
          chatId,
          `✅ *تم تفعيل الإشارات التلقائية*\nإشارة كل *${AUTO_SIGNAL_HOURS} ساعات* — صفقة واحدة فقط في وقت واحد.`,
          { parse_mode: "Markdown", reply_markup: getAdminKeyboard(true) }
        );

      } else if (text === "🔴 إيقاف الإشارات التلقائية") {
        stopAutoSignals();
        await bot!.sendMessage(
          chatId,
          "🔴 *تم إيقاف الإشارات التلقائية.*",
          { parse_mode: "Markdown", reply_markup: getAdminKeyboard(false) }
        );

      } else if (text === "🔗 رابط الويب (للـ UptimeRobot)") {
        const url = getWebUrl();
        await bot!.sendMessage(
          chatId,
          `🔗 *رابط الويب الخاص بك هو:*\n\n\`${url}\`\n\n💡 _ضعه في UptimeRobot للحفاظ على البوت يعمل 24/7._`,
          { parse_mode: "Markdown" }
        );
      }
    });

    bot.on("polling_error", (err) => {
      logger.error({ err }, "Telegram polling error");
    });
  } catch (err) {
    logger.error({ err }, "Failed to start Telegram bot");
    botActive = false;
  }
}

export function sendToChannel(channelId: string, text: string) {
  if (!bot) return;
  bot
    .sendMessage(channelId, text, { parse_mode: "Markdown" })
    .catch((err) => logger.error({ err }, "Failed to send to channel"));
}
