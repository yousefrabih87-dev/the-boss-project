import { randomUUID } from "crypto";

export type TradeStatus = "OPEN" | "CLOSED_WIN" | "CLOSED_LOSS" | "CANCELLED";
export type TradeDirection = "BUY" | "SELL";

export interface Trade {
  id: string;
  direction: TradeDirection;
  entryPrice: number;
  target: number;
  stopLoss: number;
  currentPrice?: number;
  status: TradeStatus;
  pnl?: number;
  strategy: string;
  openedAt: string;
  closedAt?: string | null;
}

export interface CreateTradeInput {
  direction: TradeDirection;
  entryPrice: number;
  target: number;
  stopLoss: number;
  strategy?: string;
}

export interface UpdateTradeInput {
  status?: TradeStatus;
  closedAt?: string;
  pnl?: number;
}

export interface TradeStats {
  totalTrades: number;
  todayTrades: number;
  openTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  totalPnl: number;
  todayPnl: number;
}

// In-memory store (resets on restart — good for demo purposes)
const trades: Trade[] = [];

export function getAllTrades(): Trade[] {
  return [...trades].sort(
    (a, b) => new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime()
  );
}

export function createTrade(input: CreateTradeInput): Trade {
  const trade: Trade = {
    id: randomUUID(),
    direction: input.direction,
    entryPrice: input.entryPrice,
    target: input.target,
    stopLoss: input.stopLoss,
    status: "OPEN",
    strategy: input.strategy ?? "SMC + SK",
    openedAt: new Date().toISOString(),
    closedAt: null,
  };
  trades.push(trade);
  return trade;
}

export function updateTrade(
  id: string,
  input: UpdateTradeInput
): Trade | null {
  const trade = trades.find((t) => t.id === id);
  if (!trade) return null;

  if (input.status !== undefined) trade.status = input.status;
  if (input.closedAt !== undefined) trade.closedAt = input.closedAt;
  if (input.pnl !== undefined) trade.pnl = input.pnl;

  return trade;
}

export function getTradeStats(): TradeStats {
  const today = new Date().toISOString().slice(0, 10);
  const todayTrades = trades.filter((t) => t.openedAt.startsWith(today));
  const closed = trades.filter(
    (t) => t.status === "CLOSED_WIN" || t.status === "CLOSED_LOSS"
  );
  const wins = trades.filter((t) => t.status === "CLOSED_WIN").length;
  const losses = trades.filter((t) => t.status === "CLOSED_LOSS").length;
  const winRate = closed.length > 0 ? (wins / closed.length) * 100 : 0;
  const totalPnl = trades.reduce((sum, t) => sum + (t.pnl ?? 0), 0);
  const todayPnl = todayTrades.reduce((sum, t) => sum + (t.pnl ?? 0), 0);
  const openTrades = trades.filter((t) => t.status === "OPEN").length;

  return {
    totalTrades: trades.length,
    todayTrades: todayTrades.length,
    openTrades,
    wins,
    losses,
    winRate: parseFloat(winRate.toFixed(1)),
    totalPnl: parseFloat(totalPnl.toFixed(2)),
    todayPnl: parseFloat(todayPnl.toFixed(2)),
  };
}
