import { logger } from "./logger";

export interface GoldPrice {
  price: number;
  symbol: string;
  source: string;
  timestamp: string;
}

export interface TradeSignal {
  signal: string;
  price: number;
  entryZone: number;
  target: number;
  stopLoss: number;
  direction: "BUY" | "SELL";
  strategy: string;
  quality: "عالية" | "متوسطة" | "جيدة";
  qualityPoints: number;
  timestamp: string;
}

// Source 1: Coinbase — real XAU/USD spot price (matches XM and forex brokers)
async function fetchFromCoinbase(): Promise<number> {
  const res = await fetch("https://api.coinbase.com/v2/prices/XAU-USD/spot", {
    signal: AbortSignal.timeout(5000),
  });
  if (!res.ok) throw new Error(`Coinbase HTTP ${res.status}`);
  const data = (await res.json()) as { data?: { amount?: string } };
  const price = parseFloat(data?.data?.amount ?? "");
  if (!isFinite(price) || price <= 0) throw new Error("Invalid Coinbase price");
  return price;
}

// Source 2: CoinGecko PAX Gold — tokenized gold closely tracking spot XAU/USD
async function fetchFromCoinGecko(): Promise<number> {
  const res = await fetch(
    "https://api.coingecko.com/api/v3/simple/price?ids=pax-gold&vs_currencies=usd",
    { signal: AbortSignal.timeout(5000) }
  );
  if (!res.ok) throw new Error(`CoinGecko HTTP ${res.status}`);
  const data = (await res.json()) as { "pax-gold"?: { usd?: number } };
  const price = data?.["pax-gold"]?.usd;
  if (!price || !isFinite(price) || price <= 0)
    throw new Error("Invalid CoinGecko price");
  return price;
}

// Source 3: Binance XAUTUSDT — tokenized gold (slight discount vs spot, last resort)
async function fetchFromBinance(): Promise<number> {
  const res = await fetch(
    "https://api.binance.com/api/v3/ticker/price?symbol=XAUTUSDT",
    { signal: AbortSignal.timeout(5000) }
  );
  if (!res.ok) throw new Error(`Binance HTTP ${res.status}`);
  const data = (await res.json()) as { price?: string };
  const price = parseFloat(data?.price ?? "");
  if (!isFinite(price) || price <= 0) throw new Error("Invalid Binance price");
  return price;
}

export async function fetchLivePrice(): Promise<GoldPrice> {
  const sources: Array<{ name: string; fetch: () => Promise<number> }> = [
    { name: "Coinbase (XAU/USD)", fetch: fetchFromCoinbase },
    { name: "CoinGecko PAX Gold", fetch: fetchFromCoinGecko },
    { name: "Binance XAUTUSDT", fetch: fetchFromBinance },
  ];

  for (const source of sources) {
    try {
      const price = await source.fetch();
      logger.info({ source: source.name, price }, "Gold price fetched");
      return {
        price,
        symbol: "XAU/USD",
        source: source.name,
        timestamp: new Date().toISOString(),
      };
    } catch (err) {
      logger.warn(
        { source: source.name, err },
        "Price source failed, trying next"
      );
    }
  }

  throw new Error("All gold price sources failed");
}

// 1 نقطة = $0.10 (معيار الذهب في منصات الفوركس)
// Stop loss ثابت دائماً = 100 نقطة = $10
// Target يتغير حسب جودة الإشارة:
//   جيدة   → 150 نقطة = $15
//   متوسطة → 175 نقطة = $17.5
//   عالية  → 200 نقطة = $20
const POINT_VALUE = 0.10; // $0.10 per point
const STOP_POINTS = 100;  // 100 points = $10

function pickQuality(): { label: "عالية" | "متوسطة" | "جيدة"; points: number } {
  const r = Math.random();
  if (r < 0.35) return { label: "جيدة",   points: 150 };
  if (r < 0.70) return { label: "متوسطة", points: 175 };
  return            { label: "عالية",   points: 200 };
}

export function generateSignal(price: number): TradeSignal {
  const direction: "BUY" | "SELL" = Math.random() > 0.4 ? "BUY" : "SELL";
  const { label: quality, points: targetPoints } = pickQuality();

  // Convert points → dollars  (100 pts × $0.10 = $10)
  const stopDollars   = parseFloat((STOP_POINTS  * POINT_VALUE).toFixed(2)); // $10
  const targetDollars = parseFloat((targetPoints * POINT_VALUE).toFixed(2)); // $15 / $17.5 / $20

  // Entry = current market price (immediate execution)
  const entryZone = parseFloat(price.toFixed(2));

  let target: number;
  let stopLoss: number;

  if (direction === "BUY") {
    target   = parseFloat((price + targetDollars).toFixed(2));
    stopLoss = parseFloat((price - stopDollars).toFixed(2));
  } else {
    target   = parseFloat((price - targetDollars).toFixed(2));
    stopLoss = parseFloat((price + stopDollars).toFixed(2));
  }

  const rr = (targetPoints / STOP_POINTS).toFixed(1);
  const qualityStars =
    quality === "عالية" ? "⭐⭐⭐" : quality === "متوسطة" ? "⭐⭐" : "⭐";

  const signal =
    `🚀 *إشارة THE BOSS — SMC + SK*\n\n` +
    `📊 الاتجاه: ${direction === "BUY" ? "🟢 شراء (BUY)" : "🔴 بيع (SELL)"}\n` +
    `💰 سعر الدخول: $${entryZone}\n` +
    `✅ الهدف: $${target} (+${targetPoints} نقطة / +$${targetDollars})\n` +
    `🛑 وقف الخسارة: $${stopLoss} (-${STOP_POINTS} نقطة / -$${stopDollars})\n` +
    `📐 نسبة R:R = 1:${rr}\n` +
    `${qualityStars} جودة الإشارة: ${quality}\n` +
    `🧠 الاستراتيجية: SMC + SK\n` +
    `🕐 ${new Date().toLocaleString("ar-SA")}\n\n` +
    `⚠️ _لن تُرسل إشارة جديدة حتى تُغلق هذه الصفقة_`;

  return {
    signal,
    price,
    entryZone,
    target,
    stopLoss,
    direction,
    strategy: "SMC + SK",
    quality,
    qualityPoints: targetPoints,
    timestamp: new Date().toISOString(),
  };
}
