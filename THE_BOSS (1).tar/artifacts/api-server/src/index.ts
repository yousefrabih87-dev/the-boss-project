import app from "./app";
import { logger } from "./lib/logger";
import { startBot } from "./lib/telegramBot";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// ── Self-ping keepalive ────────────────────────────────────────────────────
// Pings /api/healthz every 4 minutes so the server never sleeps on free-tier
// hosting (Render, Railway, etc.). Uses the public domain when available.
function startKeepalive() {
  const domains = process.env["REPLIT_DOMAINS"];
  const customUrl = process.env["PUBLIC_URL"];
  const base = customUrl
    ? customUrl.replace(/\/$/, "")
    : domains
      ? `https://${domains.split(",")[0]?.trim()}`
      : null;

  if (!base) {
    logger.info("Keepalive disabled — no public URL available");
    return;
  }

  const pingUrl = `${base}/api/healthz`;
  const INTERVAL_MS = 4 * 60 * 1000; // every 4 minutes

  setInterval(async () => {
    try {
      const res = await fetch(pingUrl, { signal: AbortSignal.timeout(10_000) });
      logger.info({ status: res.status }, "Keepalive ping OK");
    } catch (err) {
      logger.warn({ err }, "Keepalive ping failed");
    }
  }, INTERVAL_MS);

  logger.info({ pingUrl, intervalMin: 4 }, "Keepalive started");
}

// ── Start ──────────────────────────────────────────────────────────────────
app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  startBot();
  startKeepalive();
});
